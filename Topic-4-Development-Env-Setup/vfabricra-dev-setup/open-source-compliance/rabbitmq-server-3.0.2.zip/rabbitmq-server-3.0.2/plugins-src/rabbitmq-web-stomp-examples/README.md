
RabbitMQ-Web-Stomp-Examples plugin
==================================

This project contains few basic examples of RabbitMq-Web-Stomp plugin
usage.

Once installed the server will bind to port 55670 and serve few static
html files from there:

  * http://127.0.0.1:55670/

Installation
------------

Generic build instructions are at:

 * http://www.rabbitmq.com/plugin-development.html

Instructions on how to install a plugin into RabbitMQ broker:

  * http://www.rabbitmq.com/plugins.html#installing-plugins
