#define NIF_SUITE_LIB_VER 1
#include "nif_SUITE.c"
